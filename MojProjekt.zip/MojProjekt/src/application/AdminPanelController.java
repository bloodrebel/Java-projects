package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AdminPanelController implements Initializable {
	
	@FXML ListView<String> users;
	@FXML TableView<String> foods;
	@FXML TableColumn<String, String> name;
	@FXML TableColumn<String, String> cathegory;
	@FXML TableColumn<String, String> price;
	@FXML ChoiceBox<String> cb_cathegory;
	@FXML TextField tf_name;
	@FXML TextField tf_price;
	
	public void deleteuserClick(ActionEvent e) {
		
	}
public void changetypeClick(ActionEvent e) {
		
	}
public void deletefoodClick(ActionEvent e) {
	
}
public void savefoodClick(ActionEvent e) {
	
}
public void backClick(ActionEvent e) {
	try {
		Stage stage = (Stage) users.getScene().getWindow();
		Parent root = FXMLLoader.load(getClass().getResource("Menu.fxml"));
		stage.setScene(new Scene(root));
		}catch (IOException e1) {
			e1.printStackTrace();
		}
	
}


	

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		
		
	}

}
