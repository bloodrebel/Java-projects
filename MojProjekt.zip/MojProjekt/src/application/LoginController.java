package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import com.sun.javafx.scene.traversal.SceneTraversalEngine;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController implements Initializable {
	
	@FXML TextField username;
	@FXML PasswordField password;
	
	public void loginClick(ActionEvent e) {
		try {
			Stage stage = (Stage) username.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("Menu.fxml"));
			Scene scene = new Scene(root);
			stage.setScene(scene);
			
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
	}
	public void registerClick(ActionEvent e) {
		try {
			Stage stage = (Stage) username.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("Register.fxml"));
			Scene scene = new Scene(root);
			stage.setScene(scene);
			
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		
	}

}
