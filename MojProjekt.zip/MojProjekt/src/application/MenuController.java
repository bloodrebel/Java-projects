package application;

import java.awt.Desktop.Action;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class MenuController implements Initializable {
	
	@FXML TextField filter;
	@FXML ListView<String> kosarica;
	@FXML TableView<String> hrana;
	@FXML TableColumn<String,String> name;
	@FXML TableColumn<String,String> cathegory;
	@FXML TableColumn<String,String> price;
	@FXML ChoiceBox<String> kategorije;
	@FXML Label cijena;
	@FXML Label welcome;
	@FXML TextField quanity;
	
	public void clearClick(ActionEvent e) {
		
	}
	public void purchaceClick(ActionEvent e) {
		
	}
	public void movetocartClick(ActionEvent e) {
		
		
	}
	
	public void logoutClick(ActionEvent e) {
		try {
		Stage stage = (Stage) welcome.getScene().getWindow();
		Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
		stage.setScene(new Scene(root));
		}catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	public void adminClick(MouseEvent e) {
		try {
			Stage stage = (Stage) welcome.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("AdminPanel.fxml"));
			stage.setScene(new Scene(root));
			}catch (IOException e1) {
				e1.printStackTrace();
			}
		
	}
	public void userInfoClick(MouseEvent e) {
		try {
			Stage stage = (Stage) welcome.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("UserInfo.fxml"));
			stage.setScene(new Scene(root));
			}catch (IOException e1) {
				e1.printStackTrace();
			}
		
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		
	}

}
