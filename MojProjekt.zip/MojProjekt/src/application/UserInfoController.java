package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class UserInfoController implements Initializable {
	
	@FXML ListView<String> cart;
	@FXML TableView<String> items;
	@FXML TableColumn<String, String> name;
	@FXML TableColumn<String, String> cathegory;
	@FXML TableColumn<String, String> quanity;
	@FXML Label username;
	@FXML Label password;
	@FXML Label email;
	@FXML Label balance;
	@FXML Label price;
	@FXML TextField cardnumber;
	@FXML TextField money;
	@FXML Button confirm;
	
	public void backClick() {
		try {
			Stage stage = (Stage) username.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("Menu.fxml"));
			Scene scene = new Scene(root);
			stage.setScene(scene);
			
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
	}
	
	public void confirmClick(ActionEvent e) {
		
		
		
	}
	
	
	public void addmoneyClick(ActionEvent e) {
		if(cardnumber.isVisible()) {
			cardnumber.setVisible(false);
			money.setVisible(false);
			confirm.setVisible(false);
		}else {
			cardnumber.setVisible(true);
			money.setVisible(true);
			confirm.setVisible(true);
		}
		
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		
	}

}
