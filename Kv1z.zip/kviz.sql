-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 07, 2018 at 02:47 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kviz`
--

-- --------------------------------------------------------

--
-- Table structure for table `pitanja`
--

CREATE TABLE `pitanja` (
  `id` int(11) NOT NULL,
  `pitanje` varchar(70) COLLATE utf8mb4_unicode_ci NOT NULL,
  `odgovorA` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `odgovorB` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `odgovorC` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tocanodgovor` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tezina` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pitanja`
--

INSERT INTO `pitanja` (`id`, `pitanje`, `odgovorA`, `odgovorB`, `odgovorC`, `tocanodgovor`, `tezina`) VALUES
(1, 'Koji je najveci kontinent?', 'Europa', 'Azija', 'Afrika', 'Azija', 'Easy'),
(4, 'Tko je bila Hitlerova zena?', 'Eva', 'Marija', 'Isabela', 'Eva', 'Easy'),
(30, 'Gepard dok trci moze skociti...', '4 do 6 metara', '6 do 8 metara', '8 do 10 metara', '6 do 8 metara', 'Easy'),
(31, 'Koja od ovih bolesti nije zarazna ?', 'Vodene kozice', 'Rubeola', 'Rak', 'Rak', 'Easy'),
(32, 'Muzjak orke tezak je...', '1 tonu', '8 tona', '15 tona', '8 tona', 'Easy'),
(33, 'Tko je stvorio knjizevnog junaka Don Quijotea?', 'Jules Verne', 'Miguel de Cervantes', 'Ernest Hemingway', 'Miguel de Cervantes', 'Easy'),
(34, 'Koji je od ovih kraljeva bio Kralj Sunce?', 'Karlo Veliki', 'Napoleon', 'Luj XIV.', 'Luj XIV.', 'Easy'),
(35, 'U kojoj su drzavi zivjeli Azteci ?', 'Peru', 'Cile', 'Meksiko', 'Meksiko', 'Easy'),
(36, 'Koji je skladatelj bio gluh od svoje 26. godine', 'Mozart', 'Ludwig van Beethoven', 'Antonio Vivaldi', 'Ludwig van Beethoven', 'Easy'),
(37, 'Bastille je bila...', 'Kazaliste', 'Dvorac', 'Zatvor', 'Zatvor', 'Easy'),
(38, 'Sto je kinologija?', 'Nauka o psima', 'Nauka o filmovima', 'Nauka o pismu', 'Nauka o filmovima', 'Easy'),
(39, 'Himalaja je...', 'Gorski lanac', 'Drzava', 'Ocean', 'Gorski lanac', 'Easy'),
(40, 'Tko je stvorio lik Harry Pottera ?', 'J.R Tolkien', 'J.K Rowling', 'J.Jojyce', 'J.K Rowling', 'Easy'),
(41, 'Najdulja mreza podzemne zeljeznice je u ...', 'Londonu', 'New Yorku', 'Parizu', 'Londonu', 'Easy'),
(42, 'Sto simbolizira 5 krugova na znaku Olimpijskih igara ?', 'Kontinente', 'Sportove', 'Samo obicni logo', 'Kontinente', 'Easy'),
(43, 'Kako se zove osoba koja skuplja postanske marke ?', 'Filatelist', 'Filolog', 'Filantrop', 'Filatelist', 'Easy'),
(44, 'Tko je bio prvi Izraelski kralj ?', 'Saul', 'David', 'Salomon', 'David', 'Easy'),
(45, 'Koji je glavni grad Rumunjske ?', 'Bukurest', 'Riga', 'Talin', 'Bukurest', 'Easy'),
(46, 'Kojeg se dana slavi Dan drzavnosti u Hrvatskoj ?', '5.kolovoza', '22.lipnja', '25.lipnja', '25.lipnja', 'Easy'),
(47, 'Tko je naslikao Mona Lisu?', 'Michelangelo', 'Leonardo da Vinci', 'Paul Gauguin', 'Leonardo da Vinci', 'Easy'),
(48, 'Koja zivotinja grakce ?', 'Vrana', 'Krastaca', 'Krokodil', 'Vrana', 'Easy'),
(49, 'Sto znaci ime Adam ?', 'Covjek', 'Jabuka', 'Stvoren', 'Covjek', 'Easy'),
(50, 'Prvi covjek u svemiru?', 'Buzz Aldrin', 'Jurij Gagarin', 'Neil Armstrong', 'Jurij Gagarin', 'Easy'),
(51, 'Tko je napisao roman Jadnici ?', 'Victor Hugo', 'Jules Verne', 'Daniel Defoe', 'Victor Hugo', 'Easy'),
(52, 'Koja se drzava nalazi izmedu Grcke i Rumunjske ?', 'Madarska', 'Bugarska', 'Italija', 'Bugarska', 'Easy'),
(53, 'Tko je napisao poznati ep o Odiseju', 'Arhimed', 'Aristotel', 'Homer', 'Homer', 'Easy'),
(54, 'Sto je sirtaki?', 'Grcki ples', 'Poljski alkohol', 'Spanjolsko jelo', 'Grcki ples', 'Easy'),
(55, 'Kako se zove jedrilica sa dva trupa ?', 'Katamaran', 'Kanu', 'Kajak', 'Katamaran', 'Easy'),
(56, 'Koliko ima pruga na atletskoj stazi ?', '8', '10', '12', '8', 'Easy'),
(57, 'Kojeg poznatog ubojicu zena u Londonu u 19.st nikad nisu uhvatili', 'Jack Trbosjek', 'Zodiac', 'Slobodan Milosevic', 'Jack Trbosjek', 'Easy'),
(58, 'Koliko cjelokupne Zemljine povrsine zauzimaju oceani', '63%', '71%', '80%', '71%', 'Easy'),
(59, 'Koliko moze biti visoka zirafa ?', '4,5 m', '5,5 m', '6,5 m', '5,5 m', 'Easy'),
(60, 'Kako se zove dragi kamen zelene boje?', 'Rubin', 'Smaragd', 'Opal', 'Smaragd', 'Easy'),
(61, 'Sto znaci izraz monokromatski ?', 'Pastelnih boja', 'Razlicitih nijansi iste boje', 'Komplementarnih boja', 'Razlicitih nijansi iste boje', 'Easy'),
(62, 'Tko je drugi po velicini izvoznik zita na svijetu ?', 'SAD', 'Rusija', 'Kanada', 'Kanada', 'Easy'),
(63, 'Tarok se igra...', 'Sa 54 karte', 'Sa 32 karte ', 'Sa 21 kartom', 'Sa 54 karte', 'Easy'),
(64, 'Koliko je plocica potrebno za igru domino ?', '24', '26', '28', '28', 'Easy'),
(65, 'Kit uljesura moze narasti do...', '18 metara', '25 metara', '30 metara', '25 metara', 'Easy'),
(66, 'Gdje se dodjeljuje zlatna palma za filmska dostignuca ?', 'U Hollywoodu', 'U Berlinu', 'U Cannesu', 'U Cannesu', 'Easy'),
(67, 'Iz koje se igra razvio bejzbol?', 'Iz kriketa', 'Iz kroketa', 'Iz tenisa', 'Iz kriketa', 'Easy'),
(68, 'Samba je...', 'Brazilski ples', 'Portugalski ples', 'Argetinski ples', 'Brazilski ples', 'Easy'),
(69, 'Kako se zove mitolosko bice polu covjek pola konj', 'Kentaur', 'Sirena', 'Kiklop', 'Kentaur', 'Easy'),
(71, 'Odakle potjecu kanarinci ?', 'Iz Kanade', 'S Novog Zelanda', 'S Kanarskih otoka', 'S Kanarskih otoka', 'Easy'),
(72, 'Kojeg je dana drzavni praznik u SAD-u', '4.srpnja', '14.srpnja', '21.srpnja', '4.srpnja', 'Easy'),
(74, 'Mladak je mjeseceva mjena kad se Mjesec...', 'Vidi u obliku srpa', 'Vidi poput diska', 'Ne vidi', 'Ne vidi', 'Easy'),
(75, 'Gdje se u 2.st pr. Kr. izumili kisobran?', 'U Kini', 'U Perziji ', 'U Engleskoj', 'U Engleskoj', 'Easy'),
(76, 'Kojom se brzinom siri svjetlost ?', '100 000 km/s', '200 000 km/s', '300 000 km/s', '300 000 km/s', 'Easy'),
(77, 'Spartak je bio...', 'Vodja pobunjenih robova', 'Junak iz 1001 noci', 'Rimski vojnik', 'Vodja pobunjenih robova', 'Easy'),
(78, 'Koliko kg mogu biti teske morske kornjace ?', '100kg', '150kg', '300kg', '300kg', 'Easy'),
(79, 'Kada se u Kini slavi Nova godina ?', 'U prosincu', 'U sijecnju', 'U veljaci', 'U veljaci', 'Easy'),
(80, 'Koliko je zvijezda u zodijaku ?', '7', '10', '12', '12', 'Easy'),
(81, 'Koja vjera prevladava u Vijetnamu ?', 'Sintoizam', 'Budizam', 'Protestantizam', 'Budizam', 'Easy'),
(82, 'Kako se zove najstariji pronadeni zenski kostur ?', 'Lily', 'Lucy ', 'Rosy', 'Lucy ', 'Easy'),
(83, 'Kolika je prosjecna zivotna dob nasih trepavica ?', '3 mjeseca', '4 mjeseca', '2 mjeseca', '3 mjeseca', 'Easy'),
(84, 'U kojem se talijanskog gradu nalazi Duzdeva palaca', 'Venecija', 'Pisa', 'Rim', 'Venecija', 'Easy'),
(85, 'Koji je glumac glumio gospona Fulira u filmu Tko pjeva zlo ne misli ?', 'Boris Dvornik', 'Relja Basic', 'Ivo Serdar', 'Relja Basic', 'Easy'),
(86, 'Koliko je km bio dug Berlinski zid ?', '13', '23', '43', '43', 'Easy'),
(87, 'Koliko je visok Mount Everest?', '6788 m', '7652 m', '8848 m', '8848 m', 'Easy'),
(88, 'Gdje je sjediste UN-a ?', 'U Zenevi', 'U Montrealu', 'U New Yorku', 'U New Yorku', 'Easy'),
(89, 'Najveci leptir ima raspon krila...', '25cm', '28cm', '32cm', '32cm', 'Normal'),
(90, 'Pingvini su ...', 'Ptice', 'Sisavci', 'Ribe', 'Ptice', 'Normal'),
(91, 'Tko je izumio pismo za slijepe ?', 'Johann Gutenberg', 'Louis Braille', 'Nikola Tesla', 'Louis Braille', 'Normal'),
(92, 'Gdje su 1896.g bile odrzane prve Olimpijske igre modernog doba ?', 'U Parizu', 'U Montrealu', 'U Ateni', 'U Ateni', 'Normal'),
(93, 'Pompeje je unistio ...', 'Vulkan', 'Potres', 'Poplava', 'Vulkan', 'Normal'),
(94, 'Tko je uskliknuo Heureka ?', 'Tales', 'Pitagora', 'Arhimed', 'Arhimed', 'Normal'),
(95, 'Tko je tvrdio da Zemlja kruzi oko Sunca?', 'Galileo Galilei', 'Alfred Nobel', 'Isaac Newton', 'Galileo Galilei', 'Normal'),
(96, 'Indijski novac je ...', 'Rublja', 'Jen', 'Rupija', 'Rupija', 'Normal'),
(97, 'Koja rijeka ima najveci protok vode na svijetu?', 'Amazona', 'Mississippi', 'Rajna', 'Amazona', 'Normal'),
(98, 'Koji je glavni grad Kube ?', 'Buenos Aires', 'Lima', 'Havana', 'Havana', 'Normal'),
(99, 'Tko je autor teorije relativnosti ?', 'Albert Einstein', 'Platon', 'Alfred Nobel', 'Albert Einstein', 'Normal'),
(100, 'Tko je otkrio dinamit ?', 'Alfred Nobel', 'Rudolf Diesel', 'Adolf Hitler', 'Alfred Nobel', 'Normal'),
(101, 'Bendzo je ...', 'Glazbalo slicno gitari', 'Kravlji pastir u Americi', 'Vrsta Goveda', 'Glazbalo slicno gitari', 'Normal'),
(102, 'U kojoj drzavi tece rijeka Ganges ?', 'U Indiji', 'U Kini', 'U Turskoj', 'U Indiji', 'Normal'),
(103, 'Sto je \"bijeli ugljen\" ?', 'Kreda', 'Vodena energija', 'Snjezna energija', 'Vodena energija', 'Normal'),
(104, 'Kako se zove stup dzamije ?', 'Mujezin', 'Minaret', 'Medresa', 'Minaret', 'Normal'),
(105, 'Tko je napisao Othella i Macbetha ?', 'Moliere', 'Thomas Mann', 'William Shakespeare', 'William Shakespeare', 'Normal'),
(106, 'Tko je bio Dante Alighieri ?', 'Pjesnik', 'Trgovac oruzjem', 'Slikar', 'Pjesnik', 'Normal'),
(107, 'Kojom napravom mjerimo vlagu ?', 'Termometrom', 'Hidrometrom', 'Higrometrom', 'Higrometrom', 'Normal'),
(108, 'Koji nas zidovski blagdan podsjeca na izgon iz Egipta ?', 'Hanuka', 'Jom Kipur', 'Pasha', 'Pasha', 'Normal'),
(109, 'Gdje sada visi slika Mona Lise ?', 'U New Yorku', 'U Parizu', 'U Firenci', 'U Parizu', 'Normal'),
(110, 'Odakle potjece truba ?', 'Iz juzne Europe', 'Iz sjeverne Europe', 'S Bliskog istoka', 'S Bliskog istoka', 'Normal'),
(111, 'Maraton je utrka na ...', '40 km', '42 km', '46 km', '42 km', 'Normal'),
(112, 'Kako se zove kanal koji dijeli Peloponez od ostatka Grcke ?', 'Korintski kanal', 'Sueski kanal', 'Bospor', 'Korintski kanal', 'Normal'),
(113, 'U koje su mjesto isli Grci da bi im prorekli buducnost ? ', 'U Konstantinopolis', 'U Efez', 'U Delfe', 'U Delfe', 'Normal'),
(114, 'Kako se zove najveci otok Baleara ?', 'Kreta', 'Mallorca', 'Sardinija', 'Mallorca', 'Normal'),
(115, 'Pri kojoj temperaturi zavri eter ?', '34 c', '46 c', '115 c', '34 c', 'Normal'),
(116, 'Koju krvnu grupu ima univerzalni davatelj ?', 'A', 'AB', '0', '0', 'Normal'),
(117, 'Sto je bronca ?', 'Slitina ugljika i bakra ', 'Slitina bakra i kositra', 'Slitina bakra i aluminija', 'Slitina bakra i kositra', 'Normal'),
(118, 'Na kojem otoku je umro Napoleon ? ', 'Na Sv.Heleni', 'Na Elbi', 'Na Korzici', 'Na Sv.Heleni', 'Normal'),
(119, 'Koja zastava u automobilskim trkama znaci opasnost ?', 'Crno-bijela', 'Crvena', 'Zuta', 'Zuta', 'Normal'),
(120, 'Koju je drzavu vodio Mobutu ?', 'Kongo', 'Burkina Faso', 'Angolu', 'Kongo', 'Normal'),
(121, 'Koje je godine srusen Berlinski zid ?', '1988.', '1989.', '1990.', '1989.', 'Normal'),
(122, 'Odakle dolazi daska za jedrenje ?', 'S Karipskih otoka', 'S Balerskih otoka', 'Iz Polinezije', 'Iz Polinezije', 'Normal'),
(123, 'Kozaci dolaze iz ...', 'Centralne Azije', 'Juzne Afrike', 'Sjeverne Amerike', 'Centralne Azije', 'Normal'),
(124, 'Koje je godine doslo do prve naftne krize ?', '1970.', '1973.', '1978.', '1973.', 'Normal'),
(125, 'Koliki raspon krila ima albatros lutalica ?', '3,6 m', '2 m', '1,5 m', '3,6 m', 'Normal'),
(126, 'Koje je boje poznati kamen lapis lazuli ?', 'Crvene', 'Plave', 'Zelene', 'Plave', 'Normal'),
(127, 'Tko je napisao poznati hrvatski roman Zlatarovo zlato ?', 'August Senoa', 'Eugen Kumicic', 'Janko Leskovar', 'August Senoa', 'Normal'),
(128, 'Koji je europski grad prvi bio osvjetljen petrolejkama ?', 'Berlin', 'Moskva', 'Bukurest', 'Bukurest', 'Normal'),
(129, 'Koliko cunjeva treba srusiti u kuglanju ?', '12', '10', '9', '9', 'Normal'),
(130, 'Koji je otok poznat po polumajmunima ?', 'Kuba', 'Madagaskar', 'Haiti', 'Madagaskar', 'Normal'),
(131, '\"Ljudska komedija\" obuhvaca ciklus romana koje je napisao ?', 'Honore de Balzac', 'Moliere', 'Shakespeare', 'Honore de Balzac', 'Normal'),
(132, 'Gdje zive pjegave hijene ?', 'U Africi', 'U Aziji', 'U Australiji', 'U Africi', 'Normal'),
(133, 'Mustang je ...', 'Konj', 'Bik', 'Gepard', 'Konj', 'Normal'),
(134, 'Sto je kalipso ?', 'Pokrajina u Brazilu', 'Marka automobila', 'Ples s Jamajke', 'Ples s Jamajke', 'Normal'),
(135, 'Boksaci u perolakoj teze do...', '53,15kg', '63,15kg', '90,55kg', '53,15kg', 'Normal'),
(136, 'Najbrzi putnicki zrakoplov Concorde moze postici brzinu do ?', '1800km/h', '2200km/h', '2600km/h', '2200km/h', 'Normal'),
(137, 'Tko je duhovni vodja tibetanskih budista ?', 'Nirvana', 'Buda', 'Dalaj-lama', 'Dalaj-lama', 'Normal'),
(138, 'Kucni bogovi kod Rimljana zvali su se ...', 'Harpije', 'Panteoni', 'Penati', 'Penati', 'Normal'),
(139, 'Koji se jezik govori na Kapverdskim otocima ?', 'Portugalski', 'Spanjolski', 'Arapski', 'Portugalski', 'Normal'),
(140, 'Tko je otisao u potragu za zlatnim runom ?', 'Odisej', 'Jazon', 'Orest', 'Jazon', 'Normal'),
(141, 'Tko je Telemahov otac?', 'Ahil', 'Paris', 'Odisej', 'Odisej', 'Normal'),
(142, 'Jedna svjetlosna godina iznosi ...', '9461 km', '9461 milijuna km', '9461 milijarda km', '9461 milijarda km', 'Normal'),
(143, 'Kako jos nazivamo pcelarstvo ?', 'Avikultura', 'Apikultura', 'Hortikultura', 'Apikultura', 'Normal'),
(144, 'Izraz algebra je po porijeklu...', 'Arapski', 'Kineski', 'Poljski', 'Arapski', 'Normal'),
(145, 'Kad je zimski solisticij ?', 'U prosincu', 'U sijecnju', 'U veljaci', 'U prosincu', 'Normal'),
(146, 'Tko je otkrio planet Saturn ?', 'Christian Huygens', 'Nikolaj Kopernik', 'Tycho Brahe', 'Christian Huygens', 'Normal'),
(147, 'Kako se zove prva knjiga triologije Gospodar prstenova ?', 'Prstenova druzina', 'Povratak kralja', 'Dvije kule', 'Prstenova druzina', 'Normal'),
(148, 'Koja je sedma umjetnost ?', 'Slikarstvo', 'Glazba', 'Film', 'Film', 'Normal'),
(149, 'U kojem se njemackom gradu odrzava Octoberfest ?', 'U Berlinu', 'U Frankfurtu', 'U Munchenu', 'U Munchenu', 'Normal'),
(150, 'Koje je godine prvi put odrzan Tour de France ?', '1903.', '1910.', '1919.', '1903.', 'Hard'),
(151, 'Nasa 2000. bila je za zidove ...', '1420.', '2544.', '5760.', '5760.', 'Hard'),
(152, 'Koje je godine lansiran prvi satelit ?', '1924.', '1939.', '1957.', '1957.', 'Hard'),
(153, 'Koji je babilonski kralj odveo Zidove u suzanjstvo ?', 'Kralj David', 'Ramzes II.', 'Nabukodonosor', 'Nabukodonosor', 'Hard'),
(154, 'Polo je sport koji potjece iz...', 'Iz anglosanskih drzava', 'S Dalekog istoka', 'Iz Latinske Amerike', 'S Dalekog istoka', 'Hard'),
(155, 'Tko je otkrio uzrocnika tuberkuloze ?', 'Robert Koch', 'Louis Pasteur', 'Rudyard Kipling', 'Robert Koch', 'Hard'),
(156, 'U grckoj mitologiji Pegaz je...', 'Vuk', 'Pas', 'Konj', 'Konj', 'Hard'),
(157, 'Kako se zovu ratovi izmedju RImljana i Kartazana', 'Trojanski ratovi', 'Punski ratovi', 'Barbarski ratovi', 'Punski ratovi', 'Hard'),
(158, 'Gdje se nalazi Bali ?', 'U Indoneziji', 'U Polineziji', 'Na Karibima', 'U Indoneziji', 'Hard'),
(159, 'Tko je otkrio broj pi ?', 'Arhimed', 'Tales', 'Pitagora', 'Arhimed', 'Hard'),
(160, 'Mjesto s najvise oborina na svijetu je ...', 'U Kanadi', 'Na Havajima', 'Na Azorima', 'Na Havajima', 'Hard'),
(161, 'Kako se zove prvi svemirski brod koji je poletio u svemir ?', 'Sputnik I', 'Vostok I', 'NASA I', 'Vostok I', 'Hard'),
(162, 'Tko je bio Emilio Zapata ?', 'Meksicki revolucionar', 'Predsjednik SAD-a', 'Stilist', 'Meksicki revolucionar', 'Hard'),
(163, 'Koje je godine prvi put dodijeljena nagrada Oscar', '1910.', '1929.', '1935.', '1929.', 'Hard'),
(164, 'Koji je grad prijestolnica Kazahstana ?', 'Islamabad', 'Astana', 'Kartum', 'Astana', 'Hard'),
(165, 'Tko je pikador ?', 'Lopov iz spanjolske', 'Skakac s motkom', 'Torero na konju', 'Torero na konju', 'Hard'),
(166, 'Koliko otoka cini Filipine ?', 'Oko 700', 'Oko 2000', 'Oko 7000', 'Oko 7000', 'Hard'),
(167, 'Tko je znao odgovoriti na Sfinginu zagonetku ?', 'Edip', 'Ramzes II.', 'Ahil', 'Edip', 'Hard'),
(168, 'Tko je bio negus ?', 'Poznati francuski gusar', 'Etiopski car', 'Vodja grcke vojske', 'Etiopski car', 'Hard'),
(169, 'Sliku na stropu Sikstinske kapele naslikao je...', 'Peter Paul Rubens', 'Leonardo Da Vinci', 'Michelangelo', 'Michelangelo', 'Hard'),
(170, 'Gdje se nalazi mjesto Fez ?', 'U Turskoj', 'U Maroku', 'U Tunisu', 'U Maroku', 'Hard'),
(171, 'Procuavanje ovjekova karaktera po rukopisu zove se ...', 'Kaligrafija', 'Astrologija', 'Grafologija', 'Grafologija', 'Hard'),
(172, 'Kako se zove tjelesna mana covjeka koji skilji ?', 'Miopija', 'Astigmatizam', 'Strabizam', 'Strabizam', 'Hard'),
(173, 'Koliko traje jedna runda u profesionalnom boksu', '3 min', '8 min', '20 min', '3 min', 'Hard'),
(174, 'Koji je znameniti Kurd bio kralj Jeruzalema ?', 'Saladin', 'Ocalan', 'Nabukodonosor', 'Saladin', 'Hard'),
(175, 'Od cega se dobija kaucuk ?', 'Od kore ', 'Od lisca', 'Od mlijecnog soka drveta', 'Od mlijecnog soka drveta', 'Hard'),
(176, 'U kojoj drzavi se nalazi Zlatna pagoda ?', 'U Mianmaru', 'U Kini', 'U Vijetnamu', 'U Mianmaru', 'Hard'),
(177, 'Koje je najdublje jezero na svijetu ?', 'Bajkalsko', 'Blatno', 'Ontario', 'Bajkalsko', 'Hard'),
(178, 'Od koje je godine 1.svibnja medunarodni praznik rada ?', '1890.', '1905.', '1947.', '1890.', 'Hard'),
(179, 'Tigrovo oko je ...', 'Ime novca', 'Poludragi kamen', 'Rijedak insekt', 'Poludragi kamen', 'Hard'),
(180, 'Kako se zove prijestolnica Butana ?', 'Thiumphu', 'Bangkok', 'Asmara', 'Thiumphu', 'Hard'),
(181, 'Koje godine su SAD ukinule ropstvo ?', '1807.', '1836.', '1863.', '1863.', 'Hard'),
(182, 'Oriks je ...', 'Nogometna ekipa', 'Vrsta antilope', 'Poludragi kamen', 'Vrsta antilope', 'Hard'),
(183, 'Mandrili su...', 'Vrsta ptica', 'Vrsta majmuna', 'Nogometni navijaci', 'Vrsta majmuna', 'Hard'),
(184, 'Kako se zove poznati talijanski borac za slobodu ?', 'Giuseppe Garibaldi', 'Marco Polo', 'Amerigo Vespucci', 'Giuseppe Garibaldi', 'Hard'),
(185, 'Najveci glodavac moze biti dugacak do...', '60cm', '80cm', '100cm', '100cm', 'Hard'),
(186, 'Tko je izumio gromobran ?', 'Werner von Siemens', 'Ferdinand von Zeppelin', 'Benjamin Franklin', 'Benjamin Franklin', 'Hard'),
(187, 'Tko je napisao prvu hrvatsku operu Ljubav i zloba ?', 'Jakov Gotovac', 'Vatroslav Lisinski', 'Vlado Stefancic', 'Vatroslav Lisinski', 'Hard'),
(188, 'Tko se proglasio centralnoafrickim carem ?', 'Amin Dada', 'Bokassa', 'Mobutu', 'Bokassa', 'Hard'),
(189, 'Triton je satelit...', 'Saturna', 'Neptuna', 'Marsa', 'Neptuna', 'Hard'),
(190, 'Tko je autor romana \"Zbogom oruzje\" ?', 'Ernest Hemingway', 'Jack London', 'James Joyce', 'Ernest Hemingway', 'Hard'),
(191, 'Koji je pokazatelj inflacije u svakodnevnom zivotu ?', 'Snizenje cijena', 'Porast cijena', 'Porast placa', 'Porast cijena', 'Hard'),
(192, 'Kako se zovu ratovi izmedju Grka i perzijskog carstva ?', 'Punski', 'Solunski', 'Medijski', 'Medijski', 'Hard'),
(193, 'Kako se zove Orestova sestra s kojom je ubio svoju majku ?', 'Elektra', 'Ifigenija', 'Helena', 'Elektra', 'Hard'),
(194, 'Koliko je dugo trajala prohibicija u SAD-u ?', '4 godine', '14 godina', '24 godine', '14 godina', 'Hard'),
(195, 'Tko je izmislio izraz \"zeljezna zavjesa\" ?', 'Charles de Gaulle', 'Winston Churchill', 'Franklin Roosvelt', 'Winston Churchill', 'Hard'),
(196, 'Koje je godina osnovana FIFA ?', '1902.', '1911.', '1904.', '1904.', 'Hard'),
(199, 'Kojom prosjecnom brzinom trci noj ?', '10 km/h', '25 km/h', '40 km/h', '40 km/h', 'Hard'),
(200, 'Koji od ovih gradova u SAD-u cesto pogadjaju potresi ?', 'Dallas', 'Chicago', 'San Francisco', 'San Francisco', 'Hard'),
(201, 'U kojem oceanu lezi Madagaskar ?', 'U Tihom oceanu', 'U Indijskom oceanu', 'U Atlantskom oceanu', 'U Indijskom oceanu', 'Hard');

-- --------------------------------------------------------

--
-- Table structure for table `player`
--

CREATE TABLE `player` (
  `id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `highscore` int(11) NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `player`
--

INSERT INTO `player` (`id`, `username`, `password`, `highscore`, `type`) VALUES
(1, 'jozo', 'jozo', 100, 'headadmin'),
(3, 'bloodrebel', 'fear111', 0, 'normal'),
(10, 'dane', 'dane', 0, 'normal');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pitanja`
--
ALTER TABLE `pitanja`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `player`
--
ALTER TABLE `player`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pitanja`
--
ALTER TABLE `pitanja`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=203;

--
-- AUTO_INCREMENT for table `player`
--
ALTER TABLE `player`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
