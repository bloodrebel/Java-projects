package database;




import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;



public class User implements CRUD {
	private int id;
	private String username;
	private String password;
	private int highscore;
	private String type;
	
	
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public User(int id , String username , String password , int highscore,String type) {
		this.id = id;
		this.username = username;
		this.password = password;
		this.highscore = highscore;
		this.type = type;
		
	}
	
	public static ArrayList<User> getAll(){
		try {
		ArrayList<User> users = new ArrayList <>();
		ResultSet rs = Base.db.select("SELECT * FROM player");
		
		while(rs.next()) {
			users.add(new User(rs.getInt("id"),
					rs.getString("username"),
					rs.getString("password"),
					rs.getInt("highscore"),
					rs.getString("type")));
			
		}
		return users;
		} catch (SQLException e) {
			// TODO: handle exception
			System.out.println("greska u getall");
			System.out.println(e.getMessage());
			return null;
		}
		
		
		
	}
	
	public static User getById(int id) {
		try {
            PreparedStatement iskaz = Base.db.prepare("SELECT * FROM player WHERE id = ?");
            iskaz.setInt(1, id);
            ResultSet rs = iskaz.executeQuery();
            if (rs.first()) {
                return new User (
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getInt("highscore"),
                        rs.getString("type")
                        
                );
            } else {
                System.out.println("U bazi ne postoji taj user");
            }
        } catch (SQLException ex) {
            System.out.println("Gre�ka prilikom izvr�avanja upita: "+ex.getMessage());
        }
        return null;
		
		
		
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getHighscore() {
		return highscore;
	}
	public void setHighscore(int highscore) {
		this.highscore = highscore;
	}
	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
	
	@Override
	public void save() {
		PreparedStatement ps = Base.db.prepare("INSERT INTO player VALUES(null,?,?,?,?)");
			
			try {
				
				ps.setString(1, this.username);
				ps.setString(2, this.password);
				ps.setInt(3, this.highscore);
				ps.setString(4,this.type);
				ps.execute();
			} catch (SQLException e) {
				System.out.println("greska kod save-a");
			}
		
		
		
	}
	@Override
	public void update() {
		PreparedStatement ps = Base.db.prepare("UPDATE player SET username=?, password=?,highscore=?,type=?WHERE id = ?");
		try {
			ps.setString(1, this.username);
			ps.setString(2, this.password);
			ps.setInt(3, this.highscore);
			ps.setString(4, this.type);
			ps.setInt(5, this.id);
			ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("greska u update korisnika");
		}
		
		
		
	}
	@Override
	public void delete() {
		PreparedStatement ps = Base.db.prepare("DELETE FROM player WHERE id = ?");
		try {
			ps.setInt(1, this.id);
			ps.execute();
		} catch (SQLException e) {
			System.out.println("greska u brisanju korisnika");
		}
		
		
	}
	
	@Override
	public String toString() {
		return id + " - " + username;
		
	}
	
	

}
