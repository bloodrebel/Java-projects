package database;

interface CRUD {
    void save ();
    void update ();
    void delete ();
}
