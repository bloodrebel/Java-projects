package database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Pitanje implements CRUD {
	
	private int id;
	private String pitanje  ;
	private String odgovorA  ;
	private String odgovorB  ;
	private String odgovorC  ;
	private String tocanodgovor  ;
	private String tezina;
	
	
	
	public Pitanje(int id, String pitanje, String odgovorA, String odgovorB, String odgovorC, String tocanodgovor,
			String tezina) {
		
		this.id = id;
		this.pitanje = pitanje;
		this.odgovorA = odgovorA;
		this.odgovorB = odgovorB;
		this.odgovorC = odgovorC;
		this.tocanodgovor = tocanodgovor;
		this.tezina = tezina;
	}
	
	public static ArrayList<Pitanje> getAll() {
		
		try {
			ArrayList<Pitanje> pitanja = new ArrayList <>();
			ResultSet rs = Base.db.select("SELECT * FROM pitanja");
			
			while(rs.next()) {
				pitanja.add(new Pitanje(rs.getInt("id"),
						rs.getString("pitanje"),
						rs.getString("odgovorA"),
						rs.getString("odgovorB"),
						rs.getString("odgovorC"),
						rs.getString("tocanodgovor"),
						rs.getString("tezina")));
				
			}
			return pitanja;
			} catch (SQLException e) {
				// TODO: handle exception
				System.out.println("greska u getall");
				System.out.println(e.getMessage());
				return null;
			}
		
		
	}
	
public static ArrayList<Pitanje> getByDifficulty(String diff) {
		
		try {
			ArrayList<Pitanje> pitanja = new ArrayList <>();
			PreparedStatement ps = Base.db.prepare("SELECT * FROM pitanja WHERE tezina = ?");
			ps.setString(1, diff);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				pitanja.add(new Pitanje(rs.getInt("id"),
						rs.getString("pitanje"),
						rs.getString("odgovorA"),
						rs.getString("odgovorB"),
						rs.getString("odgovorC"),
						rs.getString("tocanodgovor"),
						rs.getString("tezina")));
				
			}
			return pitanja;
			} catch (SQLException e) {
				// TODO: handle exception
				System.out.println("greska u getall");
				System.out.println(e.getMessage());
				return null;
			}
		
		
	}

	
	

	@Override
	public void save() {
		PreparedStatement ps = Base.db.prepare("INSERT INTO pitanja VALUES(null,?,?,?,?,?,?)");
		try {
		ps.setString(1, this.pitanje);
		ps.setString(2, this.odgovorA);
		ps.setString(3, this.odgovorB);
		ps.setString(4, this.odgovorC);
		ps.setString(5, this.tocanodgovor);
		ps.setString(6, this.tezina);
		ps.execute();
		} catch(SQLException e) {
			System.out.println("Greska kod save-a");
			
		}
		
		
	}

	@Override
	public void update() {
		PreparedStatement ps = Base.db.prepare("UPDATE pitanja SET pitanje=?,odgovorA=?,odgovorB=?,odgovorC=?,tocanodgovor=?,tezina=? WHERE id=?");
		try {
		ps.setString(1, this.pitanje);
		ps.setString(2, this.odgovorA);
		ps.setString(3, this.odgovorB);
		ps.setString(4, this.odgovorC);
		ps.setString(5, this.tocanodgovor);
		ps.setString(6, this.tezina);
		ps.setInt(7, this.id);
		ps.execute();
		} catch(SQLException e) {
			System.out.println("Greska kod update-a");
			
		}
		
		
	}

	@Override
	public void delete() {
		PreparedStatement ps = Base.db.prepare("DELETE FROM pitanja WHERE id=?");
		try {
		ps.setInt(1, this.id);
		ps.execute();
		}catch (SQLException e) {
			System.out.println("Greska kod delet-a");
		}
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPitanje() {
		return pitanje;
	}

	public void setPitanje(String pitanje) {
		this.pitanje = pitanje;
	}

	public String getOdgovorA() {
		return odgovorA;
	}

	public void setOdgovorA(String odgovorA) {
		this.odgovorA = odgovorA;
	}

	public String getOdgovorB() {
		return odgovorB;
	}

	public void setOdgovorB(String odgovorB) {
		this.odgovorB = odgovorB;
	}

	public String getOdgovorC() {
		return odgovorC;
	}

	public void setOdgovorC(String odgovorC) {
		this.odgovorC = odgovorC;
	}

	public String getTocanodgovor() {
		return tocanodgovor;
	}

	public void setTocanodgovor(String tocanodgovor) {
		this.tocanodgovor = tocanodgovor;
	}

	public String getTezina() {
		return tezina;
	}

	public void setTezina(String tezina) {
		this.tezina = tezina;
	}

	
	

}
