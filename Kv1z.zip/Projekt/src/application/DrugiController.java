package application;



import java.io.IOException;


import database.Pitanje;
import database.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;

public class DrugiController {
	
	private ObservableList<User> obs;
	private ObservableList<Pitanje> pitanja;
	
	@FXML
	private Button ct;
	@FXML
	private Button du;
	@FXML
	private Label lb1;
	
	@FXML
	private Label password;
	@FXML
	private Label highscore;
	@FXML
	private Label type;
	
	@FXML
	private TableView<Pitanje> tablica;
	@FXML
	public TableColumn<Pitanje,String> pitanje;
	@FXML
	public TableColumn<Pitanje,String> odgovorA;
	@FXML
	public TableColumn<Pitanje,String> odgovorB;
	@FXML
	public TableColumn<Pitanje,String> odgovorC;
	@FXML
	public TableColumn<Pitanje,String> tocanodgovor;
	@FXML
	public TableColumn<Pitanje,String> tezina;
	@FXML
	private ListView<User> myListView;
	@FXML
	private RadioButton a;
	@FXML
	private RadioButton b;
	private FilteredList<Pitanje> filteredList;
	@FXML TextField tField_pitanje;
	@FXML TextField tField_a;
	@FXML TextField tField_b;
	@FXML TextField tField_c;
	@FXML TextField search;
	@FXML Label tekst;
	@FXML ToggleGroup odgovori;
	@FXML ToggleGroup tez;
	
	public void changeType(ActionEvent e){
		User user = myListView.getSelectionModel().getSelectedItem();
		if(user!=null){
		if(user.getType().equals("normal")){
			user.setType("admin");
			user.update();
		}else if(user.getType().equals("admin")){
			user.setType("normal");
			user.update();
		}
		
		type.setText(user.getType());
		
		}
		
		
	}
	public void saveQuestion(ActionEvent e) {
		
		a = (RadioButton)odgovori.getSelectedToggle();
		b = (RadioButton)tez.getSelectedToggle();
		
		if(tField_pitanje.getText().isEmpty() || tField_a.getText().isEmpty() || tField_b.getText().isEmpty() || tField_c.getText().isEmpty()) {
			tekst.setText("Empty fields");
			
		}else {
			tekst.setText("");
			if(a.getText().equals("A")) {
			new Pitanje(0, tField_pitanje.getText(),tField_a.getText(), tField_b.getText(), tField_c.getText(), tField_a.getText(),b.getText()).save();

			}else if(a.getText().equals("B")) {
				new Pitanje(0, tField_pitanje.getText(),tField_a.getText(), tField_b.getText(), tField_c.getText(), tField_b.getText(),b.getText()).save();
				} else {
					
					new Pitanje(0, tField_pitanje.getText(),tField_a.getText(), tField_b.getText(), tField_c.getText(), tField_c.getText(),b.getText()).save();

				}
			
		}
		pitanja= FXCollections.observableArrayList(Pitanje.getAll());
		filteredList = new FilteredList<>(pitanja);
		filteredList.setPredicate(pitanje -> {
			if(search == null || search.equals("")){
				return true;
			}else if (pitanje.getPitanje().toLowerCase().contains(search.getText().toLowerCase())){
				
				return true;
			}else if(pitanje.getTezina().toLowerCase().equals(search.getText().toLowerCase())){
				return true;
			}
			
			
			return false ;
			
			
		});
		tablica.setItems(filteredList);
		tField_pitanje.setText("");
		tField_a.setText("");
		tField_b.setText("");
		tField_c.setText("");
				
		
		
	}
	
	public void deleteQuestion() {
		for(Pitanje p : tablica.getSelectionModel().getSelectedItems()) {
			p.delete();
		}
		
		pitanja = FXCollections.observableArrayList(Pitanje.getAll());
		filteredList = new FilteredList<>(pitanja);
		filteredList.setPredicate(pitanje -> {
			if(search == null || search.equals("")){
				return true;
			}else if (pitanje.getPitanje().toLowerCase().contains(search.getText().toLowerCase())){
				
				return true;
			}else if(pitanje.getTezina().toLowerCase().equals(search.getText().toLowerCase())){
				return true;
			}
			
			
			return false ;
			
			
		});
		tablica.setItems(filteredList);
		
	}
	

public void delete() {
	User user = myListView.getSelectionModel().getSelectedItem();
	if(!user.getType().equals("headadmin")){
	user.delete();
	obs = FXCollections.observableArrayList(User.getAll());
	myListView.setItems(obs);
	password.setText("");
	highscore.setText("");
	type.setText("");
	}
	
}
	
	
	@FXML
	public void back(ActionEvent e) {
		
		
		Stage stage = (Stage)tablica.getScene().getWindow();
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/application/Menu.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(Main.class.getResource("theme.css").toExternalForm());
			stage.setScene(scene);
			stage.show();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	
	
	}
	public void initialize() {
		
		obs = FXCollections.observableArrayList(User.getAll());
		pitanja = FXCollections.observableArrayList(Pitanje.getAll());
		myListView.setItems(obs);
		tablica.setEditable(true);
		tablica.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		pitanje.setCellValueFactory(new PropertyValueFactory<Pitanje,String>("pitanje"));
		odgovorA.setCellValueFactory(new PropertyValueFactory<Pitanje,String>("odgovorA"));
		odgovorB.setCellValueFactory(new PropertyValueFactory<Pitanje,String>("odgovorB"));
		odgovorC.setCellValueFactory(new PropertyValueFactory<Pitanje,String>("odgovorC"));
		tocanodgovor.setCellValueFactory(new PropertyValueFactory<Pitanje,String>("tocanodgovor"));
		tezina.setCellValueFactory(new PropertyValueFactory<Pitanje,String>("tezina"));
		tablica.setItems(pitanja);
		
		pitanje.setCellFactory(TextFieldTableCell.forTableColumn());
		odgovorA.setCellFactory(TextFieldTableCell.forTableColumn());
		odgovorB.setCellFactory(TextFieldTableCell.forTableColumn());
		odgovorC.setCellFactory(TextFieldTableCell.forTableColumn());
		tocanodgovor.setCellFactory(TextFieldTableCell.forTableColumn());
		tezina.setCellFactory(TextFieldTableCell.forTableColumn());
		filteredList = new FilteredList<>(pitanja, p -> true);
search.textProperty().addListener(e ->{
		filteredList.setPredicate(pitanje -> {
			if(search == null || search.equals("")){
				return true;
			}else if (pitanje.getPitanje().toLowerCase().contains(search.getText().toLowerCase())){
				
				return true;
			}
			else if(pitanje.getTezina().toLowerCase().equals(search.getText().toLowerCase())){
				return true;
			}
			
			return false ;
			
			
		});
		
			
		});
tablica.setItems(filteredList);
		
		
		
		pitanje.setOnEditCommit(e -> {
			((Pitanje)e.getTableView().getItems().get(e.getTablePosition().getRow())).setPitanje(e.getNewValue());
			((Pitanje)e.getTableView().getItems().get(e.getTablePosition().getRow())).update();
			
		});
		
		odgovorA.setOnEditCommit(e -> {
			((Pitanje)e.getTableView().getItems().get(e.getTablePosition().getRow())).setOdgovorA(e.getNewValue());
			((Pitanje)e.getTableView().getItems().get(e.getTablePosition().getRow())).update();
			
		});
		odgovorB.setOnEditCommit(e -> {
			((Pitanje)e.getTableView().getItems().get(e.getTablePosition().getRow())).setOdgovorB(e.getNewValue());
			((Pitanje)e.getTableView().getItems().get(e.getTablePosition().getRow())).update();
			
		});
		odgovorC.setOnEditCommit(e -> {
			((Pitanje)e.getTableView().getItems().get(e.getTablePosition().getRow())).setOdgovorC(e.getNewValue());
			((Pitanje)e.getTableView().getItems().get(e.getTablePosition().getRow())).update();
			
		});
		tocanodgovor.setOnEditCommit(e -> {
			((Pitanje)e.getTableView().getItems().get(e.getTablePosition().getRow())).setTocanodgovor(e.getNewValue());
			((Pitanje)e.getTableView().getItems().get(e.getTablePosition().getRow())).update();
			
		});
		tezina.setOnEditCommit(e -> {
			
			if(e.getNewValue().equals("Easy") || e.getNewValue().equals("Normal") || e.getNewValue().equals("Hard")) {
			((Pitanje)e.getTableView().getItems().get(e.getTablePosition().getRow())).setTezina(e.getNewValue());
			((Pitanje)e.getTableView().getItems().get(e.getTablePosition().getRow())).update();
			}
		});
		MenuController.mediaPlayer.setOnEndOfMedia(new Runnable() {
			public void run() {
				MenuController.mediaPlayer.stop();
				MenuController.mediaPlayer.play();
				MenuController.running = true;
				
			}
		});
	
		myListView.getSelectionModel().selectedItemProperty().addListener(e -> {
			if(myListView.getSelectionModel().getSelectedItem()==null){
				password.setText("");
				highscore.setText("");
				type.setText("");
				return;
			}
			password.setText(myListView.getSelectionModel().getSelectedItem().getPassword());
			highscore.setText(""+myListView.getSelectionModel().getSelectedItem().getHighscore());
			type.setText(myListView.getSelectionModel().getSelectedItem().getType());
			

			
		});
		if(!LoginController.logeduser.getType().equals("headadmin")){
			password.setVisible(false);
			ct.setVisible(false);
			du.setVisible(false);
			lb1.setVisible(false);
			
			
		}
		
		
		
	}

}
