package application;


import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import database.Base;
import database.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController {
	
	
	public static User logeduser;
	
	@FXML
	private TextField username;
	@FXML
	private PasswordField password;
	@FXML
	private Label info;
	
	
	@FXML
	public void login(ActionEvent e)  {
		PreparedStatement upit = Base.db.prepare("SELECT * FROM player WHERE username=? and password=?");
			
			try {
				upit.setString(1, username.getText());
				upit.setString(2, password.getText());
				ResultSet rs = upit.executeQuery();
				if(rs.first()) {
					
					logeduser = new User(rs.getInt("id"),rs.getString("username"),rs.getString("password"),rs.getInt("highscore"),rs.getString("type"));
					Stage stage = (Stage) password.getScene().getWindow();
					Parent root = FXMLLoader.load(getClass().getResource("/application/Menu.fxml"));
					Scene scene = new Scene(root);
					scene.getStylesheets().add(Main.class.getResource("theme.css").toExternalForm());
					stage.setScene(scene);
					
					
				}else {
					info.setText("Korisnicki podaci nisu tocni");
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		
		
			
			
			
		
		
	}
	
	public void register(ActionEvent e) {
		try {
		Stage stage = (Stage) password.getScene().getWindow();
		Parent root = FXMLLoader.load(getClass().getResource("/application/Register.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(Main.class.getResource("theme.css").toExternalForm());
		stage.setScene(scene);
		} catch (IOException ex) {
			
		}
		
		
		
	}
	
	public void initialize() {
		
		
	}

}
