package application;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import database.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.SortType;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class HighscoreController implements Initializable{
	
	@FXML
	private TableView<User> tablica;
	@FXML
	private TableColumn<User, String> player;
	@FXML
	private TableColumn<User,Integer> score;
	
	private ObservableList<User> obs;
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		obs = FXCollections.observableArrayList(User.getAll());
		
		score.setSortType(SortType.DESCENDING);
		player.setCellValueFactory(new PropertyValueFactory<User,String>("username"));
		score.setCellValueFactory(new PropertyValueFactory<User,Integer>("highscore"));
		tablica.setItems(obs);
		tablica.getSortOrder().addAll(score);
		
		MenuController.mediaPlayer.setOnEndOfMedia(new Runnable() {
			public void run() {
				MenuController.mediaPlayer.stop();
				MenuController.mediaPlayer.play();
				MenuController.running = true;
				
			}
		});
		
		
		
	}
	
	public void back(ActionEvent e) {
		Stage stage = (Stage)((Button)e.getSource()).getScene().getWindow();
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/application/Menu.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(Main.class.getResource("theme.css").toExternalForm());
			stage.setScene(scene);
			stage.show();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

}
