package application;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;



import database.Base;
import database.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RegisterController implements Initializable{
	
	@FXML
	private PasswordField register_password;
	
	@FXML
	private PasswordField register_passwordcheck;
	
	@FXML
	private TextField register_username;
	
	@FXML
	private Label register_label;
	
	public void back(ActionEvent e) {
		
		try {
			Stage stage = (Stage) register_password.getScene().getWindow();
			Parent root = FXMLLoader.load(getClass().getResource("/application/Login.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(Main.class.getResource("login.css").toExternalForm());
			stage.setScene(scene);
			} catch (IOException ex) {
				
			}
		
	}
	
	public void confirm(ActionEvent e) {
		if(register_password.getText().equals(register_passwordcheck.getText()) && !(register_username.getText().isEmpty() || register_password.getText().isEmpty()) && validate(register_username.getText())) {
			
			
			try {
				PreparedStatement ps = Base.db.prepare("SELECT * FROM player WHERE username = ?");
				ps.setString(1, register_username.getText());
				ResultSet rs = ps.executeQuery();
				if(!rs.first()) {
					
					User novi = new User(0, register_username.getText(), register_password.getText() , 0, "normal");
					novi.save();
					register_label.setText("You have succesfuly registered");
					}else {
						register_label.setText("Username already exists");
						
					}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
			
			
		} else {
			
			register_label.setText("Invalid username/password entered");
		}
		
		
		
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		
	}
	
	public boolean validate(String text){
		char[] chararr = text.toCharArray();
		for(char c: chararr){
			if(!Character.isLetterOrDigit(c)){
				return false;
				
			}
		}
		
			
		
		
		return true;
	}

}
