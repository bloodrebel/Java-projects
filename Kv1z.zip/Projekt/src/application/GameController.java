package application;

import java.applet.Applet;
import java.applet.AudioClip;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;
import database.Pitanje;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class GameController implements Initializable {
	@FXML private Button btn1;
	@FXML private Button btn2;
	@FXML private Button btn3;
	@FXML private Label tekst;
	@FXML private Label score;
	@FXML private Rectangle traka;
	@FXML private Label life;
	private ArrayList<Pitanje> pitanja = new ArrayList<>();
	private ArrayList<Integer> container = new ArrayList<>();
	private Random rand = new Random();
	private int position;
	private Pitanje current;
	int br = 0;
	public static boolean vrijeme;
	public static int rez;
	public static int zivot;
	private AudioClip clipY;
	private AudioClip clipN;
	Timer timer = new Timer();
	
	

	public void btn1Click(ActionEvent e) {
		if(btn1.getText().equals(current.getTocanodgovor())) {
			clipY.play();
			rez+=MenuController.tezina;
			score.setText("Score:\n"+rez+"");
			zamjeni();
		}else {
			zivot--;
			life.setText("Zivot : " + zivot);
			clipN.play();
			if(zivot < 1) {
				timer.cancel();
				Stage stage = (Stage)((Button)e.getSource()).getScene().getWindow();
				try {
					Parent root = FXMLLoader.load(getClass().getResource("/application/End.fxml"));
					Scene scene = new Scene(root);
					scene.getStylesheets().add(Main.class.getResource("end.css").toExternalForm());
					stage.setScene(scene);
					stage.show();
					return;
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			zamjeni();
		}
		
	}
	
public void btn2Click(ActionEvent e) {
	
	if(btn2.getText().equals(current.getTocanodgovor())) {
		clipY.play();
		rez+=MenuController.tezina;
		score.setText("Score:\n"+rez+"");
		zamjeni();
	}else {
		zivot--;
		life.setText("Zivot : " + zivot);
		clipN.play();
		if(zivot < 1) {
			timer.cancel();
			Stage stage = (Stage)((Button)e.getSource()).getScene().getWindow();
			try {
				Parent root = FXMLLoader.load(getClass().getResource("/application/End.fxml"));
				Scene scene = new Scene(root);		
				scene.getStylesheets().add(Main.class.getResource("end.css").toExternalForm());
				stage.setScene(scene);
				stage.show();
				return ;
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		zamjeni();
	}
		
		
	}

public void btn3Click(ActionEvent e) {
	
	if(btn3.getText().equals(current.getTocanodgovor())) {
		clipY.play();
		rez+=MenuController.tezina;
		score.setText("Score:\n"+rez+"");
		zamjeni();
	}else {
		zivot--;
		life.setText("Zivot : " + zivot);
		clipN.play();
		if(zivot < 1) {
			timer.cancel();
			Stage stage = (Stage)((Button)e.getSource()).getScene().getWindow();
			try {
				Parent root = FXMLLoader.load(getClass().getResource("/application/End.fxml"));
				Scene scene = new Scene(root);
				scene.getStylesheets().add(Main.class.getResource("end.css").toExternalForm());
				stage.setScene(scene);
				stage.show();
				return ;
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		zamjeni();
	}
	
	
}
public void btn4Click(ActionEvent e) {
	timer.cancel();
	Stage stage = (Stage)((Button)e.getSource()).getScene().getWindow();
	try {
		Parent root = FXMLLoader.load(getClass().getResource("/application/Menu.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(Main.class.getResource("theme.css").toExternalForm());
		stage.setScene(scene);
		stage.show();
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		rez = 0;
		zivot = 3;
		vrijeme = true;
		tekst.setWrapText(true);
		score.setText("Score:\n"+rez+"");
		life.setText("Zivot : " + zivot);
		pitanja.addAll(Pitanje.getByDifficulty(MenuController.tezinaS));
		postavi();
		zamjeni();
		clipY=Applet.newAudioClip(GameController.class.getResource("/sounds/musical002.wav"));
		clipN=Applet.newAudioClip(GameController.class.getResource("/sounds/cartoon006.wav"));
		setTimer();
		
		
		
	}
	
	
	
	public void postavi() {
		
		while(br<pitanja.size()) {
			position = rand.nextInt(pitanja.size()) + 0;
			if(!container.contains(position)) {
				container.add(position);
			br++;
			}
			
		}
		
		br=0;
		
		
	}
	public void zamjeni() {
		try {
		current = pitanja.get(container.get(br));
		tekst.setText(current.getPitanje());
		btn1.setText(current.getOdgovorA());
		btn2.setText(current.getOdgovorB());
		btn3.setText(current.getOdgovorC());
		br++;
		
			
		}catch(IndexOutOfBoundsException ex) {
			timer.cancel();
			try {
				Stage stage = (Stage)tekst.getScene().getWindow();
				Parent root = FXMLLoader.load(getClass().getResource("/application/End.fxml"));
				Scene scene = new Scene(root);
				scene.getStylesheets().add(Main.class.getResource("end.css").toExternalForm());
				stage.setScene(scene);
				stage.show();
				
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
		}
		
	}
	public void setTimer() {
			
			
			timer.scheduleAtFixedRate(new TimerTask() {
				
				@Override
				public void run() {
					if(traka.getWidth()<=0) {
						timer.cancel();
						vrijeme = false;
						Stage stage = (Stage)tekst.getScene().getWindow();
						try {
							Parent root = FXMLLoader.load(getClass().getResource("/application/End.fxml"));
							Scene scene = new Scene(root);
							scene.getStylesheets().add(Main.class.getResource("end.css").toExternalForm());

							Platform.runLater(() -> stage.setScene(scene));
							
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
					}
					
					
					
					Platform.runLater(() -> traka.setWidth(traka.getWidth()-0.6));
				
					
				}
			},0,100);
		
		
		
		
		
	}
	
	
	
	}



		
		
		
		
		
	


