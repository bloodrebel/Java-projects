package application;


import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

public class MenuController implements Initializable{
	@FXML Label changepw;
	@FXML PasswordField pw;
	@FXML PasswordField reenterpw;
	@FXML Button confirm;
	
	@FXML
	private Label logeduser_menu;
	
	@FXML
	private Button btn_options;
	
	@FXML
	private ImageView imgg;
	
	@FXML private ChoiceBox<String> cb_menu;
	public   static Media media = new Media(new File("chocobo_song.mp3").toURI().toString());
	public   static MediaPlayer mediaPlayer = new MediaPlayer(media);
	public static boolean running = false;
	public static int tezina;
	public static String tezinaS;
	
	
	public void confirmClick(ActionEvent e){
		if(!pw.getText().isEmpty() && !reenterpw.getText().isEmpty() && pw.getText().equals(reenterpw.getText())){
		LoginController.logeduser.setPassword(pw.getText());
		LoginController.logeduser.update();
		pw.setText("");
		reenterpw.setText("");
		pw.setVisible(false);
		reenterpw.setVisible(false);
		confirm.setVisible(false);
		}
		
	}
	public void changepwClick(MouseEvent e){
		if(pw.isVisible()){
		pw.setVisible(false);
		reenterpw.setVisible(false);
		confirm.setVisible(false);
		pw.setText("");
		reenterpw.setText("");
		
		}else {
			pw.setVisible(true);
			reenterpw.setVisible(true);
			confirm.setVisible(true);
		}
	}
	
	public void promjeni(MouseEvent e){
		if(mediaPlayer.isMute()){
			mediaPlayer.setMute(false);
			
			Image image = new Image(getClass().getResource("/slike/sazvukom.png").toExternalForm());
			imgg.setImage(image);
		}else {
			mediaPlayer.setMute(true);
			
			Image image = new Image(getClass().getResource("/slike/bezzvuka.png").toExternalForm());
			imgg.setImage(image);
			
		}
		
		
		
	}
	
	public void OptionsClick(ActionEvent event ) {
		
		try {
			Stage stage = (Stage)btn_options.getScene().getWindow();
			Parent root;
			root = FXMLLoader.load(getClass().getResource("Drugi.fxml"));
			stage.setScene(new Scene(root));
		} catch (IOException e) {
			
		}
	
		
		
	}
	
public void HighScoreClick(ActionEvent event ) {
	try {
		Stage stage = (Stage)btn_options.getScene().getWindow();
		Parent root;
		root = FXMLLoader.load(getClass().getResource("Highscore.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(Main.class.getResource("theme.css").toExternalForm());
		stage.setScene(scene);
		
	} catch (IOException e) {
		
	}

		
		
	}

public void NewGameClick(ActionEvent event ) {
	tezina = cb_menu.getSelectionModel().getSelectedIndex() + 1;
	tezinaS= cb_menu.getSelectionModel().getSelectedItem();
	try {
		mediaPlayer.stop();
		running = false;
		Stage stage = (Stage)btn_options.getScene().getWindow();
		Parent root;
		root = FXMLLoader.load(getClass().getResource("Game.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(Main.class.getResource("game.css").toExternalForm());
		stage.setScene(scene);
	} catch (IOException e) {
		
	}
	
	
}

public void LogoutClick(ActionEvent event ) {
	
	try {
		mediaPlayer.stop();
		running = false;
		Stage stage = (Stage)btn_options.getScene().getWindow();
		Parent root;
		root = FXMLLoader.load(getClass().getResource("Login.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(Main.class.getResource("login.css").toExternalForm());
		stage.setScene(scene);
	} catch (IOException e) {
		
	}

	
	
}


	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		pw.setVisible(false);
		reenterpw.setVisible(false);
		confirm.setVisible(false);
		
		ArrayList<String> al = new ArrayList<String>();
		al.add("Easy");
		al.add("Normal");
		al.add("Hard");
		cb_menu.setItems(FXCollections.observableArrayList((al)));
		cb_menu.getSelectionModel().selectFirst();
		
		if(LoginController.logeduser.getType().equals("normal")) {
			btn_options.setVisible(false);
		}
	
		
		logeduser_menu.setText("Welcome " + LoginController.logeduser.getUsername());
		if(running == false) {
		mediaPlayer.play();
		running = true;
		}
		
		mediaPlayer.setOnEndOfMedia(new Runnable() {
			public void run() {
				mediaPlayer.stop();
				mediaPlayer.play();
				running = true;
				
			}
		});
		
		if(mediaPlayer.isMute()){
			
			Image image = new Image(getClass().getResource("/slike/bezzvuka.png").toExternalForm());
			imgg.setImage(image);
			
		}else {
			
			
			Image image = new Image(getClass().getResource("/slike/sazvukom.png").toExternalForm());
			imgg.setImage(image);
			
			
		}
		
	}

}
